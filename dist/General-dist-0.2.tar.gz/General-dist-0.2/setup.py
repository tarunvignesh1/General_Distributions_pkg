from setuptools import setup

setup(name='General-dist',
      version='0.2',
      description='distributions',
      packages=['Generaldist'],
author = 'Tarun Vignesh',
author_email = 'tarunvignesh1@gmail.com',
      zip_safe=False)
